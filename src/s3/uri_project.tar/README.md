# uri

A Clojure library designed to ... well, that part is up to you.

## Usage

FIXME

## License

Copyright © 2012 FIXME

Distributed under the Eclipse Public License, the same as Clojure.
